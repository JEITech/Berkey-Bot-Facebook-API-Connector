'use strict'
var FB = require('facebook-bot-messenger');
function checker(value){

  if (typeof value != undefined){

    return value;

  }else{

    return 1;

  }

};
module.exports = {
  create : function(){
    var theClient = FB.create({
      pageID: checker(process.env.PAGE_ID),
      appID: checker(process.env.APP_ID),
      appSecret: checker(process.env.APP_SECRET),
      validationToken: checker(process.env.PAGE_VALIDATION_TOKEN),
      pageToken: checker(process.env.PAGE_ACCESS_TOKEN)
    });
    return theClient;
  }
}
