'use strict'
var VERIFY_TOKEN = 'berkeyToken';
var PAGE_ACCESS_TOKEN = process.env.PAGE_ACCESS_TOKEN;
var https = require('https');
var sa = require('superagent');

function lexify(senderID, messageText){


  sendTextMessage(senderID, messageText);

}

function receivedMessage(event) {

  var senderID = event.sender.id;
  var recipientID = event.recipient.id;
  var timeOfMessage = event.timestamp;
  var message = event.message;
  var messageId = message.mid;
  var messageText = message.text;
  var messageAttachments = message.attachments;

  if (messageText) {

        lexify(senderID, messageText);

  } else if (messageAttachments) {
    sendTextMessage(senderID, "Message with attachment received");
  }

}

function sendTextMessage(recipientId, messageText) {
  var messageData = {
    recipient: {
      id: recipientId
    },
    message: {
      text: messageText
    }
  };
  callSendAPI(messageData);
}

function callSendAPI(messageData) {
  var postData = JSON.stringify(messageData);
  var path = '/v2.6/me/messages?access_token=' + PAGE_ACCESS_TOKEN;
  var options = {
    host: "graph.facebook.com",
    path: path,
    method: 'POST',
    headers: {'Content-Type': 'application/json'}
  };
  var callback = function(response) {
    var str = ''
    response.on('data', function (chunk) {
      str += chunk;
    });
    response.on('end', function () {

    });
  }
  var req = https.request(options, callback);
  req.on('error', function(e) {
    console.log('problem with request: '+ e);
  });

  req.write(body);
  req.end();

  sa.post('graph.facebook.com' + path)
      .set('Content-Type', 'application/json')
      .send(postData)
      .end(function(er, res){
      if(er){


        }else{

       }
     });
}

exports.handler = async (event, context, callback) => {
    try {
      if(event.queryStringParameters){
         var queryParams = event.queryStringParameters;

         var rVerifyToken = queryParams['hub.verify_token']

         if (rVerifyToken === VERIFY_TOKEN) {
           var challenge = queryParams['hub.challenge']

           var response = {
             'body': parseInt(challenge),
             'statusCode': 200
           };

           callback(null, response);
         }else{
           var response = {
             'body': 'Error, wrong validation token',
             'statusCode': 422
           };

           callback(null, response);
         }
       }else{

         var data = JSON.parse(event.body);

    // Make sure this is a page subscription
    if (data.object === 'page') {
    // Iterate over each entry - there may be multiple if batched
    data.entry.forEach(function(entry) {
        var pageID = entry.id;
        var timeOfEvent = entry.time;
        // Iterate over each messaging event
        entry.messaging.forEach(function(msg) {
          if (msg.message) {
            receivedMessage(msg);
          } else {
            //console.log("Webhook received unknown event: ", event);
          }
        });
    });

    var response = {
  'body': "ok",
  'statusCode': 200
};

callback(null, response);

       }

    }

  }catch (err) {
        callback(err);
    }
};
